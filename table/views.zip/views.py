from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q
from django.shortcuts import render
from sphinxapi import SphinxClient
from .models import User
from datetime import date


def main_index(request):
    if request.GET:
        first_name = request.GET.get('First_name')
        s = SphinxClient()
        s.SetServer('127.0.0.1', 9306)
        s.SetLimits(0, 100)
        result = s.Query(first_name, index='my_test')
        users = []
        print(s)
        if result and result['status'] == 0 and result['total']:
            matches = {row.get('id'): row.get('first_name') for row in result['matches']}
            if matches:
                users = [u for u in User.objects.filter(id__in=matches.keys()).all()]
                users.sort(key=lambda a: matches.get(a.id, 0))

        return render(request, 'main/index.html',
                      {
                          'First_name': first_name,
                          'datas': users,
                      })

    else:
        users = User.objects.filter(birthday__day=date.today().day, birthday__month=date.today().month)
        context = {
            'datas': users
        }
        return render(request, 'main/index.html',
                      context)


def name(request):
    first_name = request.GET.get('First_name')
    last_name = request.GET.get('Last_name')

    s = SphinxClient()
    s.SetServer(host='127.0.0.1', port=9306)
    s.SetLimits(0, 30)
    result = s.Query(first_name, index='search')
    users = []
    if result and result['status'] == 0 and result['total']:
        matches = {row.get('id'): row.get('first_name') for row in result['matches']}
        if matches:
            users = [u for u in User.objects.filter(id__in=matches.keys()).all()]
            users.sort(key=lambda a: matches.get(a.id, 0))
    return render(request, 'main/index.html',
                  {'datas': users})
    # elif last_name:
    #     s = SphinxClient()
    #     s.SetServer('127.0.0.1', 9306)
    #     return render(request, 'main/index.html', {'datas': User.objects.filter(Q(last_name__icontains=last_name))})

# def search(request):
#     if request.GET:
#         form = SearchForm(request.GET)
#         query = request.GET.get('q', '')
#         s = SphinxClient()
#         s.SetServer('localhost', 5432)
#         s.SetLimits(0,16777215)
#         if s.Status():
#             query_result = s.Query(query)
#             total = query_result['total']
#             pages_id = [page['id'] for page in query_result['matches']]
#             if pages_id:
#                 result = User.objects.filter(id__in=pages_id)
#             else:
#                 result = None
#             if result:
#                 paginator = Paginator(result,25)
#                 page = request.GET.get('page')
#                 try:
#                     result = paginator.page(page)
#                 except PageNotAnInteger:
#                     result = paginator.page(1)
#                 except EmptyPage:
#                     result = paginator.page(paginator.num_pages)
#             return render(request, 'main/search.html',
#                           {
#                               'result' : result, 'total' : total,
#                               'query' : query, 'form' : form
#                           })
#     else:
#         form = SearchForm()
#         return render(request, 'main/search.html', {'form' : form})
